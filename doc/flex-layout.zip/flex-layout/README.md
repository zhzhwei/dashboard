Angular Flex-Layout
=======

The sources for this package are in the main [Angular Flex-Layout](https://github.com/angular/flex-layout) repo. 
Please file issues and pull requests against that repo.

License: MIT
