/**
 * *****************************************************************
 * Define module for common Angular Layout utilities
 * *****************************************************************
 */
import * as ɵngcc0 from '@angular/core';
export declare class CoreModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDef<CoreModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<CoreModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<CoreModule>;
}

//# sourceMappingURL=module.d.ts.map