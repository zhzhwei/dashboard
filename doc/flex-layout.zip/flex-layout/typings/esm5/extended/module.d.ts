/**
 * *****************************************************************
 * Define module for the Extended API
 * *****************************************************************
 */
export declare class ExtendedModule {
}
