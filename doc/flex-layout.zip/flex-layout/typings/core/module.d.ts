/**
 * *****************************************************************
 * Define module for common Angular Layout utilities
 * *****************************************************************
 */
export declare class CoreModule {
}
