==count(distinct ?s)==

## bar chart
fixed: 
- prefixes
- some kinda number as y

variable: 
- x
- f(x) (more or less)

fetch all relevant skills for bar chart:
```ts
this.query = this.rdfDataService.prefixes + `
            select distinct ?skillName where {
                ?s rdf:type edm:JobPosting.
                ?s edm:title ?title.
                filter contains(?title, "${this.jobName}").
                ?s edm:hasSkill ?skill.
                ?skill edm:textField ?skillName.
                filter (lang(?skillName) = "de").
            } Order By ASC (?skillName)
        `;
```
select distinct x?


### Beschriftung x-Achse
(Beispiel: Skills für Polymechaniker)
Anzahl Balken = Anzahl Ergebnisse

```SPARQL
SELECT DISTINCT ?skillName
WHERE {
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    
    filter contains(?title, "Polymechaniker").
    
    ?s edm:hasSkill ?skill.
    ?skill edm:textField ?skillName.
    FILTER (lang(?skillName) = "de").
}
ORDER BY ?skillName
```

select distinct *gewählte Property*
where {
	job posting und title
	filter nach queryParameters
	vorgefertigter Block für selectParameter 
}

Beispiel fulltimeJob
![[Pasted image 20240117093448.png]]
bro what

```SPARQL
SELECT DISTINCT ?fulltimeJob
WHERE {
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    filter contains(?title, "Polymechaniker").
    
    ?s mp:isFulltimeJob ?fulltimeJob
}
```

Beispiel dateCreated
```SPARQL
SELECT distinct ?created WHERE { 
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    
    ?s edm:dateCreated ?createdTime.
    FILTER (xsd:dateTime("2023-10-15T00:00:00Z") < xsd:dateTime(?created)).
    FILTER (xsd:dateTime(?created) < xsd:dateTime("2023-10-20T00:00:00Z")).
    BIND(xsd:dateTime(concat(SUBSTR(str(?createdTime), 1, 10),"T00:00:00Z")) AS ?created)
}
```
-> kann d3 fehlende Daten abfangen und mit 0 auffüllen?

## "f(x)"
Beispiel: zähle Skills für
```SPARQL
SELECT ?skillName (COUNT(?s) AS ?occurrences)
WHERE {
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    
    filter contains(?title, "Polymechaniker").
    
    ?s edm:hasSkill ?skill.
    ?skill edm:textField ?skillName.
    FILTER (lang(?skillName) = "de").
    
    FILTER (?skillName IN ("CNC-Schleifen"@de, 
"Steuerungskenntnisse"@de))
}
GROUP BY ?skillName
```

select distinct *gewählte Property*
where {
	job posting und title
	filter nach queryParameters
	vorgefertigter Block für selectParameter 
	+ filter in *Liste von vorher*
} group by *gewählte Property*


Beispiel fulltimeJob
```SPARQL
SELECT ?fulltimeJob (COUNT(?s) AS ?occurrences)
WHERE {
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    filter contains(?title, "Polymechaniker").
    ?s mp:isFulltimeJob ?fulltimeJob
}
GROUP BY ?fulltimeJob
```
 -> ideally combine the two falses






## Line chart

Beispiel alle job postings, pro Zeit, in Zeitspanne
```SPARQL
SELECT ?created (COUNT(?s) AS ?occurrences) WHERE { 
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    ?s edm:dateCreated ?createdTime.
    FILTER (xsd:dateTime("2023-10-15T00:00:00Z") < xsd:dateTime(?created)).
    FILTER (xsd:dateTime(?created) < xsd:dateTime("2023-10-20T00:00:00Z")).
	BIND(xsd:dateTime(concat(SUBSTR(str(?createdTime), 1, 10),"T00:00:00Z")) AS ?created)
} 
group by ?created
```

Beispiel alle postings für Polymechaniker in Zeitspanne
```SPARQL
SELECT ?created (COUNT(?s) AS ?occurrences) WHERE { 
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    
    filter contains(?title, "Polymechaniker")
    
    ?s edm:dateCreated ?createdTime.
    FILTER (xsd:dateTime("2023-10-15T00:00:00Z") < xsd:dateTime(?created)).
    FILTER (xsd:dateTime(?created) < xsd:dateTime("2023-10-20T00:00:00Z")).
	BIND(xsd:dateTime(concat(SUBSTR(str(?createdTime), 1, 10),"T00:00:00Z")) AS ?created)
} 
group by ?created
```

Beispiel alle postings mit Skill über Zeit
```SPARQL
SELECT ?created (COUNT(distinct ?s) AS ?occurrences) WHERE { 
    ?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    
    ?s edm:hasSkill ?skill.
	?skill edm:textField "Selbstständigkeit"@de.
	
    ?s edm:dateCreated ?createdTime.
	BIND(xsd:dateTime(concat(SUBSTR(str(?createdTime), 1, 10),"T00:00:00Z")) AS ?created)
} 
group by ?created
```

count distinct ?s ist scheinbar wichtig v(. _ .)v
