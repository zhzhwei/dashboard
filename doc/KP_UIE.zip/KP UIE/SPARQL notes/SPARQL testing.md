select all job postings:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
PREFIX : <http://ai4bd.com/resource/ddm/mp/shape#>
select * where { 
	?s rdf:type edm:JobPosting.
}
```

all full time job postings:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
PREFIX mp: <http://ai4bd.com/resource/ddm/mp/>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
select * where { 
	?s rdf:type edm:JobPosting;
    	mp:isFulltimeJob "true"^^xsd:boolean.
}

```
alternatively "false", i dunno what happened there

all full time job postings and their title:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
PREFIX mp: <http://ai4bd.com/resource/ddm/mp/>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
select ?s ?title where { 
	?s rdf:type edm:JobPosting.
    ?s	mp:isFulltimeJob "true"^^xsd:boolean.
    ?s	edm:title ?title.
}

```


count all full time job postings:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
PREFIX mp: <http://ai4bd.com/resource/ddm/mp/>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
select (COUNT(*) as ?count) where { 
	?s rdf:type edm:JobPosting.
    ?s	mp:isFulltimeJob "true"^^xsd:boolean.
}
```

job postings with specific title:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
select * where { 
	?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    ?s edm:title "6 CNC-Polymechaniker für den Schleifbereich gesucht!"
}
```

search with partial matches:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
select * where { 
	?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    filter contains(?title, "Recyclist für langfristige Tätigkeit gesucht")
}
```

all polymechanics and the skills they list:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
select * where { 
	?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    filter contains(?title, "Polymechaniker").
    ?s edm:hasSkill ?skill.
}
```

include only the german names of skills:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
select * where { 
	?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    filter contains(?title, "Polymechaniker").
    ?s edm:hasSkill ?skill.
    ?skill 	edm:textField ?skillName.
    filter (lang(?skillName) = "de")
}
```


so count all polymechanics: 8

get list of all possible skills that occur:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
select distinct ?skillName where { 
	?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    filter contains(?title, "Polymechaniker").
	?s edm:hasSkill ?skill.
    ?skill edm:textField ?skillName.
    filter (lang(?skillName) = "de").
}

```

use this with a count for all occurrences of a single skill:
```SPARQL
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX edm: <http://ai4bd.com/resource/edm/>
select * where { 
	?s rdf:type edm:JobPosting.
    ?s edm:title ?title.
    filter contains(?title, "Polymechaniker").
	?s edm:hasSkill ?skill.
    ?skill edm:textField ?skillName.
    filter (lang(?skillName) = "de").
    filter (?skillName = "CNC-Schleifen"@de).
}
```



Gesamt 8
"CNC-Schleifen"@de, 
"Steuerungskenntnisse"@de, 
"Selbstständigkeit"@de, 
"Qualitätsbewusstsein"@de, 
"Unternehmerisches Denken"@de, 
"Teamfähigkeit"@de, 
"Kundenorientierung"@de, 
"Flexibilität"@de, 
"Leitungsbereitschaft"@de, 
"Polymechanik"@de, 
"Bewerbungsmanagement"@de, 
"Kommunikationsfähigkeit"@de, 
"Organisationsfähigkeit"@de, 
"Analytische Fähigkeiten"@de, 
"Problemlösungsfähigkeit"@de