https://en.wikipedia.org/wiki/SHACL

SHACL = Shapes Constraint Language
- standard language for describing [[RDF]] graphs
- defined in terms of constraints on the content, structure and meaning of a graph
- can express conditions that constrain 
	- the number of values that a property may have
	- the type of such values
	- numeric ranges
	- string matching patterns
- and logical combinations of such constraints
- SHACL Rules add inferencing capabilities, so you can infer new statements from existing statements


### Terminology
#### Property Shapes
- describes characteristics of graph nodes that can be reached via a specific graph
- path = single predicate or chain of predicates
- must always specify a path (sh:path predicate)
- property shapes with simple paths describe values of certain properties, e.g. values of an age property
- property shapes can be defined as part of a node shape
  node shape - sh:property - property shape
- property shapes can also be stand-alone

#### Node Shapes
- describes characteristics of specific graph nodes irrespective of how you get to them
- it is common to include a property shape in a node shape, effectively defining values of many different properties of a node
- example: a node shape for an employee may incorporate property shapes for "age" and "works for" properties

#### Constraints
- way to describe different characteristics of a value
- a shape will include one or more constraint declarations
- many pre-built constraint types are included in SHACL
  example: sh:datatype, sh:minCount, sh:length

#### Targets
- connects a shape with data it describes
- simpest way to specify a target: say that a node shape is also a class
  therefore its definition applies to all members (instances) of a class
- other ways to define a target of a shape:
	- explicitly saying that a shape targets members of a certain class (can be done instead of making a node shape also a class)
	- saying that a shape targets a soecific resource by giving its URI
	- saying that a shape targets all subjects or all objects of triples with a certain predicate
	- using a SPARQL query to select a set of resources to be targeted
- target declarations can be included in both node and property shapes (node shape takes priority here if property shape is part of node)