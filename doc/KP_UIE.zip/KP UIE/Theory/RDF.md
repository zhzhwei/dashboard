https://en.wikipedia.org/wiki/Resource_Description_Framework

RDF = Ressource Description Framework
- originally designed as data model for metadata
- now general method for description and exchange of graph data
- directed graph composed of triple statements
	- node for the subject
	- arc from subject to object
	- node for object (object can be literal value)
- each of these 3 parts has an URI (unique ressource identifier)
- [[SPARQL]] = standard query language for RDF graphs
- [[SHACL]] = ontology language used to describe RDF data


### Overview
- similar to entity-relationship diagrams and class diagrams in that it makes statements about resources
- but it makes statements about the subject, not the object or entity

- uses expressions in the form "subject-predicate-object"
  Example: the sky (subject) has the color (predicate) blue (object)
- for reference: typical approach of entity-attribute-value model
  entity (sky), attribute (color), value (blue)

- subject denotes the ressource
- predicate denotes traits or aspects of the resource AND also expresses the relationship between subject and object

- a collection of RDF statements leads to a labeled, directed multigraph (multiple edges per vertex are allowed)

### Resource identification
- subject of an RDF statement is either a URI or a blank node (these are called anonymous resources)
- predicate is a URI
- object is a URI, a blank node or a unicode string literal
- as of RDF 1.1 (2014), resources are identified by IRIs (Internationalized Resource Identifiers), a generalization of URIs

### Statement reification and context
reification = each statement (= each triple) us assigned a URI and treated as a ressource about which one can make additional statements
- in some implementations, you can associate statements with a context (via an "is true in" relationship)
- you can also group statements by their source

![[Pasted image 20231016150303.png]]