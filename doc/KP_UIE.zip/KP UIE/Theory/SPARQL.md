https://en.wikipedia.org/wiki/SHACL

SPARQL = SPARQL Protocol and RDF Query Language
- [[RDF]] query language
- allows for a query to consist of
	- triple patterns
	- conjunctions
	- disjunctions
	- optional patterns
- normal SQL database: columns with named attributes, 1 row = 1 entity
- RDF database: 3 columns, subject predicate object
- multiple entries per predicate possible

### Query forms
SELECT
- extract raw values from an endpoint, results are returned as a table
CONSTRUCT
- extract information from an endpoint and transforms the result into valid RDF
ASK
- provide simple True/False result for a query
DESCRIBE
- extract an RDF graph, the content of which is left to the endpoint to decide

each of these query forms takes a WHERE block to restrict the query


## Wikidata Query Service Tutorial
https://wdqs-tutorial.toolforge.org/

- wikidata consists of items, URIs for those start with a Q
- for properties they start with P
- items also have a label, its main name in a given language (doesn't have to be unique)

 
![[Pasted image 20231016164053.png]]

```SPARQL
#this query shows all films that are part of the star wars series
SELECT ?item  #names of the variables that will be returned by the query
WHERE  #often in the form of triples
{
	?item wdt:P179 wd:Q22092344  #wdt is short for http://www.wikidata.org/prop/direct/>:P179
}
#so this is basically:
#?item – has property:part of a series – with value:Star Wars (film series)
```

### Adding Labels
```SPARQL
SELECT ?item  ?itemLabel 
WHERE 
{ 
  ?item wdt:P179 wd:Q22092344.
SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE]". } #specialized service for retrieving the labels
#you can also specify the language, e.g. "nl"
#or fallback options if a label doesn't exist in a language, e.g. "fr,de,en"
}
```

### Queries retrieving a statement value
```SPARQL
#retrieving all actors for a given movie
SELECT ?actor ?actorLabel 
WHERE 
{ 
  wd:Q17738 wdt:P161 ?actor. 
SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE]". }
}

```


### Adding match patterns
```SPARQL
#AND relation between the patterns:
SELECT ?item  ?itemLabel 
WHERE 
{ 
  ?item wdt:P179 wd:Q22092344. # item is part of the series Star Wars (film series)
  ?item wdt:P57 wd:Q38222.     # item has director property with value George Lucas.
  SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE]". }
}
#or shorter: 
SELECT ?item  ?itemLabel
WHERE 
{ 
  ?item wdt:P179 wd:Q22092344;
  	   	wdt:P57 wd:Q38222.
  SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE]". }
}

#OR relation:
SELECT ?item  ?itemLabel 
WHERE 
{ 
  {?item wdt:P179 wd:Q22092344.} # item is part of Star Wars (film series)
  UNION                          # OR
  {?item wdt:P179 wd:Q1102217.}   # item is part of the Star Trek film series
  SERVICE wikibase:label { bd:serviceParam wikibase:language "[AUTO_LANGUAGE]". }
}
```