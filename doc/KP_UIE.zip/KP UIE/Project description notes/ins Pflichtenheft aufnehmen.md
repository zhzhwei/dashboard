Barchart stretch goals: 
- mehrere einfache Barcharts zu einem stacked kombinieren
- zwei barcharts mit Transparenz übereinanderlegen (versetzte Balken idealerweise)
- bei stacked barchart mehrere Checkboxen welche Farben man anzeigen möchte

starplot stretch goal: transparenz
- 2-3 starplots übereinander (4 max!)
	- wenn man auf einen klickt, sieht man nur den einen (Interaktivität)
- ideal definieren und das als Overlay haben

![[Pasted image 20231101133328.png]]