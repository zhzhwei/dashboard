title should be something with "report"

## how to install the project
- node 14.17.5  (https://nodejs.org/en/blog/release/v14.17.5)
- should come with npm 6.14.14
- angular 12.2.18  (npm install -g @angular/cli@12.2.18)
- clone the repository
- (potentially transplant @angular/flex-layout into node_modules)
- npm install
- ng serve
- open localhost:4200 in browser
  (or use ng serve -o)

## developer handbook
### dependencies
found in package.json, but the most important ones are:
bootstrap: 5.3.2
chart.js: 4.4.0
d3: 5.16.0
gridstack: 4.2.6

### project structure
(organized by folder structure, starting with src)
### config 
standard folder for saving/loading diagram configs
### assets 
- all images, like the visualization select images in the wizard
- text file with all job names, used for the suggestions on the job name input (lists like this can be used to add suggestions to fields where you can't use the raw values, like the title field in our case)

### app
#### diagram
only bar-chart and line-chart are interesting here, the other ones are deprecated
(though doughnut and star-plot generate examples with dummy data)

these components generate the diagram on the actual tile and determine what happens, when a user clicks one of the edit/save/inventory/delete buttons

copeChartAction() is the most interesting method here, it creates the actual svg with the diagram in it, using d3
the dataSource for that is currently read from localstorage, not ideal

would greatly benefit from at least a shared interface that they all implement
maybe even an abstract visualization.component to inherit from, the edit/save/inventory/delete buttons has a lot of duplication


#### dialog
- components for the various dialogs opened on top of the dashboard
- most interesting ones are the editors and vis-gen-dialog

##### bar-chart-editor and line-chart-editor
- dialog you get to after the wizard OR when the user clicks the edit button
- allows user to set title, color of the bars/line
- additionally bar visibility for bar-chart-editor
- gets the data either from shared.service (if from wizard) or localstorage (if from dashboard)
- saves visibiltyMapping in localstorage (which just encodes which of the data points get rendered)
- creates chart similar to bar-chart.component/line-chart.component

##### vis-gen-dialog
- contains the wizard
- preview section uses subcomponents bar-chart-preview and line-chart-preview
- loads job name and skill suggestions into datalists (job names from src/assets/ and skills from system.service)
- queryMappings is used to add filter statements to the query, depending on the filters selected by the user
- generates and executed the preview query
- opens the editor corresponding to the selected visualization type

##### bar-chart-preview and line-chart-preview
- contain the mapping of user-selected properties to the x- and y-axis of the visualization
- generate and execute the data query (with a special case for skills)
- use the same queryMappings block as vis-gen-dialog
- write their results to shared.service to be used in the editor
- again, would benefit from more abstraction, like a shared interface or an abstract preview.component


#### gridstack
- initializes the grids (major and minor/inventory)
- generates the tiles to be displayed
- handles chart actions (edit/save/inventory/delete)
- handles tiles switching grids (e.g. by being dragged out of the minor/inventory grid into the major one)


#### services
| name                 | description                                                                                               |
| -------------------- | --------------------------------------------------------------------------------------------------------- |
| chart.service.ts     | functionality for saving to/loading from json-file and browser localstorage                               |
| dialog.service.ts    | opens the delete dialogs (single tile or all tiles), snackbars, and the different editor dialogs          |
| gridstack.service.ts | handles the creation of new tiles and saving its size and position data                                   |
| icon.service.ts      | adds the title and edit/save/inventory/delete buttons to the dashboard tiles                              |
| rdf-data.service.ts  | communicates with SPARQL endpoint, stores prefixes needed for SPARQL queries                              |
| shared.service.ts    | used for passing SPARQL query results between the preview component in wizard to its corresponding editor |
| system.service.ts    | stores a (hand-written) list of all skillNames and their abbreviations                                    |


#### app.component.html
contains the buttons at the top and the major grid container

### TLA (image)
==to be added==



additional headlines:
GUI screenshots (together with scenarios)
-> all scenarios, don't sell yourself short

sparql queries, including the work we did on pie chart

known bugs/things that don't work

future plans
- more visualization types
- more abstraction (abstract editor and preview components)
- get away from single dataset
- more customization for the editor
- tile interaction
- more user guidance/feedback
- multiple values for filters (like multiple job names)
- live data support/multiple tile types

any further documentation we made and where to find it

also clean up gitlab


