
includes 
- working plan 
- concrete requirements and constraints regarding users, context and tasks
- research of related work (so like our inspo?)
- for now focus on planning, requirements, ...

- introduction to topic
- description of the tasks/goals
- important related work and other topic-related resources
- be specific about what you do and don't do
- functional/non-functional requirements
- must-haves/optional requirements
- structure of the project, e.g. through work packages (so like first we get the app running, then we work on the dashboard, ...)
- timining of the project, schedule of packages
- work distribution between team members


1. Purpose
    1. [Definitions](https://en.wikipedia.org/wiki/Definition "Definition")
    2. Background
    3. System overview
    4. [References](https://en.wikipedia.org/wiki/Reference "Reference")
2. [Overall description](https://en.wikipedia.org/wiki/High-_and_low-level "High- and low-level")
    1. [Product perspective](https://en.wikipedia.org/wiki/Product_requirements_document "Product requirements document")
        1. [System Interfaces](https://en.wikipedia.org/wiki/Interface_(computing) "Interface (computing)")
        2. [User interfaces](https://en.wikipedia.org/wiki/User_interface "User interface")
        3. [Hardware interfaces](https://en.wikipedia.org/wiki/Hardware_interfaces "Hardware interfaces")
        4. [Software interfaces](https://en.wikipedia.org/wiki/Interface_(computing) "Interface (computing)")
        5. Communication Interfaces
        6. [Memory constraints](https://en.wikipedia.org/wiki/Computer_memory "Computer memory")
    2. Design constraints
        1. [Operations](https://en.wikipedia.org/wiki/Operations_support_system "Operations support system")
        2. Site adaptation requirements
    3. Product functions
    4. User characteristics
    5. Constraints, assumptions and dependencies
3. Specific requirements
    1. External interface requirements
    2. [Performance requirements](https://en.wikipedia.org/wiki/Performance_engineering "Performance engineering")
    3. Logical database requirement
    4. [Software system attributes](https://en.wikipedia.org/wiki/Software_requirements_specification#SoftwareSystemAttributes)
        1. [Reliability](https://en.wikipedia.org/wiki/Reliability_engineering "Reliability engineering")
        2. [Availability](https://en.wikipedia.org/wiki/High_availability "High availability")
        3. [Security](https://en.wikipedia.org/wiki/Security_engineering "Security engineering")
        4. [Maintainability](https://en.wikipedia.org/wiki/Serviceability_(computer) "Serviceability (computer)")
        5. Portability
    5. [Functional requirements](https://en.wikipedia.org/wiki/Functional_requirements "Functional requirements")
        1. [Functional partitioning](https://en.wikipedia.org/w/index.php?title=Functional_partitioning&action=edit&redlink=1 "Functional partitioning (page does not exist)")
        2. [Functional description](https://en.wikipedia.org/w/index.php?title=Functional_description&action=edit&redlink=1 "Functional description (page does not exist)")
        3. [Control description](https://en.wikipedia.org/w/index.php?title=Control_description&action=edit&redlink=1 "Control description (page does not exist)")
    6. [Environment characteristics](https://en.wikipedia.org/w/index.php?title=Environment_characteristics&action=edit&redlink=1 "Environment characteristics (page does not exist)")
        1. [Hardware](https://en.wikipedia.org/wiki/Computer_hardware "Computer hardware")
        2. [Peripherals](https://en.wikipedia.org/wiki/Peripherals "Peripherals")
        3. [Users](https://en.wikipedia.org/wiki/User_(computing) "User (computing)")
    7. Other


Zusammenfassung
Aufgabenstellung und Zielsetzung
Produktnutzung
Interessengruppen (Stakeholders)
Systemgrenze und Top-Level-Architektur
Anwendungsfälle
Funktionale Anforderungen
Nicht-Funktionale Anforderungen
GUI-Prototyp
Datenmodell
Akzeptanztestfälle


Ausgangssituation und Zielsetzung
Funktionale Anforderungen
Nicht-Funktionale Anforderungen
Gesamtarchitektur
Sicherheitsrelevante Anforderungen, ...
Schnittstellenübersicht
Abnahmekriterien
Anforderungsvervolgung (Verbindung zwischen Anforderungen und Systemarchitektur)

part 1: intro niceties
- maybe abstract
- intro
- task
- maybe related work

part 2: requirements, what are we supposed to do
- requirements (all of the kinds)
- use cases (here already?)


part 3: design/concept and implementation
- technologies we're using
- pick requirements apart into aspects
- go over the general design ideas
- good, better and best for these aspects


part 4: how do we go about doing this
- work plan
- roughly who does what


### intro
- goal is a proof-of-concept prototype
- for the flexible visualization tool for semantic data
- for company elevait
- tool used for exploring semantic data
- web application

### requirements
#### functional required
- user can generate visualizations of 4 different types
- user can select data to be visualized
- user can define filters for to be visualized data 
- user can customize the data mapping (colors)

- user can arrange visualiztions on a dashboard
- dashboard tiles are draggable and resizeable
- visualization tiles have labeled axes
- user can delete visualizations

- program can query existing GraphDB database
- program runs as a web app on PC, operated with a mouse


#### functional optional
- user can customize the data mapping (add counts, grouping)
- user can give visualizations custom titles
- user can "stash" visualizations
- user can share visualizations they made with other users
- stretch goal: interactivity within the visualizations
- UI can be operated via touchscreen

#### NOT included
- no interactions between visualizations, they're standalone

#### non-functional
- visualize complex data types (dunno what to make of that yet)
- can visualize any semantic dataset
-  the chosen visualizations are good for different aspects of the data
- user-friendly, so the user doesn't have to write SPARQL queries (user is not required to know SPARQL)
- tool should be scalable to some degree (like adding more visualizations or more customizations)
- non-functional: min/max datapoints -> ties into responsiveness
- readability: code should be readable and documented

focus: exchangable dataset, responsiveness



### implementation
- idea: wizard for building visualizations
- idea: config files that get saved
- angular, gridstack, d3

### work plan
- get a running app
- make a dashboard
- establish communication to elevait DB, run some example queries
- make a simple query builder
- config file system, save query to config file
- generate visualization from config file
- connect query and visualization


### aspects
- wizard (create)
- editor/configurator (customize)
- dashboard (arrange)
- the visualizations themselves
- communication to elevait DB
- config files, import/export
- controls (mouse/touch)



config file system
- some sort of text file
- human-readable
- contains the sparql query and all settings regarding the visualization
- using only the config file, you can generate the exact same visualization -> import file
- there is some sort of list of unused visualizations ("stash") that the user can drag onto the dashboard

good:
- settings and sparql query get saved in config file
- fixed file path
- to import files, the user just copies them into the directory

better:
- imported visualizations can be selected from a list and dragged onto the dashboard
- the user can specify the file name

best:
- files can be added to the "inventory" via file browser
- inventory contains tiles with preview images



libraries and frameworks: include GraphDB
rename configurator into editor

gui prototype ideas
- plus button with context menu for vis type
- or multiple small icons


visualizations
- line graph (erweiterbar zu stacked area chart)
- bar chart (erweiterbar zu stacked bar chart)
- boxplot
- starplot
- backup: pie chart


### Intro
Welcome to our dynamic project description for the development of an innovative dashboard application designed to showcase a diverse array of visualizations. This dashboard is fueled by the power of semantic data, and its primary objective is to provide users with meaningful insights and an intuitive interface for data exploration. As we embark on this journey, it's important to note that this project description is a living document. It serves as our compass, outlining our vision and plans for the application, but it will remain flexible and evolve as the project progresses. Join us as we navigate the exciting landscape of data visualization and deliver a cutting-edge tool for data-driven decision-making.

Welcome to our project description for the development of a dynamic dashboard application designed to showcase an array of visualizations, each derived from semantic data. This project marks the inception of an exciting journey, as we aim to create an insightful and user-friendly platform that harnesses the power of data visualization. As a living document, this description will serve as our evolving blueprint, detailing our strategies and milestones throughout the project. Join us on this collaborative adventure, as we embark on the quest to bring data to life through compelling and interactive visualizations.

Welcome to our project description for the development of a comprehensive dashboard application, designed to present a range of visualizations derived from semantic data. This dashboard serves as a pivotal tool for users seeking insightful data analysis and exploration. It is essential to understand that this project description is a living document, meticulously detailing our plans for the application, and it will undergo revisions throughout the project's lifecycle. We invite you to join us on this journey as we navigate the complex realm of data visualization and deliver a sophisticated, data-centric decision-making solution.


Welcome to our project description for the development of a dashboard application designed to visualize semantic data. This project description will lay out our design decisions and implementation plans for the application. Furthermore, it is a living document and will undergo multiple revisions thoughtout the project. 


The primary goal of this project is to develop a proof-of-concept prototype for a web-based dashboard application. The application's focus is to serve as a flexible visualization tool for semantic data. With it, the user will be able to create and customize visualizations and arrange them on a dashboard, both in an effort to facilitate data exploration. Additionally, the prototype is built with extensibility in mind, so new visualization types or customization options can be added in the future.

Our objective is to empower users to create diverse visualizations and arrange them on a dashboard, thereby facilitating seamless data exploration. This task marks the initial step in the project, and its successful execution will lay the foundation for the full-fledged development of the dashboard application.