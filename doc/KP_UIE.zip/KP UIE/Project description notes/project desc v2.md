
- "when creating a new visualization, user chooses data set and visualization type first, those are immutable": 
- den Datensatz erst zu wählen würde ich nicht bestreiten, aber ist es tatsächlich sinnvoll, dass der User als erstes auch gleich die Visualisierung wählt? 
- das setzt voraus, dass der User von vornherein eine klare Erwartungshaltung hat, was das Aussehen anbelangt, noch bevor er weiß, was für Daten tatsächlich im Datensatz drin stecken. 
- Das kann durchaus der Fall sein (siehe Use Cases), muss aber nicht immer so sein. 
- Ihr könnt das gern festlegen, aber da wäre eine genauere Use Case Analyse vielleicht vorher besser. 
- Vielleicht braucht es auch einen Zwischenschritt, in dem man die Daten, die vorhanden sind und visualisiert werden sollen, inspiziert?


- [ ] use cases -> Hauptziel des Nutzers, Erwartungshaltung