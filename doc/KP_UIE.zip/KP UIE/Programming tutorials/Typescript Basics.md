### Data types
keep strict mode on, it helps keep things clean
- string, bumber, boolean, array, enum, tuple, any, void, never
- you don't *have* to declare the datatype when initializing the variable, but you should (ts infers the data type from the initial value)
```ts
let lname : string;
lname = "Santosh"
//or in short:
let lname : string = "Santosh"

let result = parseInt("25")  //type inference

let emptyList : string[]
let genericList : Array<string>  //typed like Java generics
```
- no more mixed use arrays, now only one datatype

```ts
enum Color {
	Red,
	Green,
	Blue
}
let c: Color = Color.Red
```
here tsc does some magic
all of which can be stripped away by making the enum const, then c is a mere index

### Functions
different ways to write functions: named functions, arrow function, anonymous function
```ts
function swapNumbers(num1: number, num2: number) : [number, number] {
	// do something
}

const sub = (num1: number, num2: number) : number => num1 - num2

const mult = function (num1: number, num2: number) : number {
	// do something
}

//optional parameter:
function foo(num1: number, nums?: number) {
	num2? num1 + num2 : num1*2
}

//default value:
function bar(num1: number, num2=10) {}

//rest parameter (user can specify however many values for num3)
function foobar(num1: number, num2: number, ...num3: number[]) {}
foobar(1, 2, ...[1, 2, 4])
//or:
numbers = [1, 2, 4]
foobar(1, 2, ...numbers)
//or:
foobar(1, 2, 3, 4, 5, 6)
```

generic functions
```ts
function getItems<T>(items: T[]): T[] {
return new Array<T>().concat(items)
}
let concatResult = getItems([1, 2, 3])
//or:
let concatResult2 = getItems<number>([1, 2, 3])
```

### Classes
```ts
class Employee {
	#id: number;  //private property
	name: string;
	address: string = ""
	
	static getEmployeeCount(): number {}
	
	constructor(id: number, name: string) {
		this.#id = id
		this.name = name
	}

	getNameWithAddress() : string {
		return this.name +  " " + this.address
	}
}

let john = new Employee(1, "John")
john.address = "Highway 71"

let msg = john.getNameWithAddress()
Employee.getEmployeeCount()
```
properties and functions are public by default

there is also the protected keyword, which means that properties/functions are accessible by derived classes
but they are inaccessible from the outside

inheritance with extends keyword and super() call in constructor

set and get keywords :0!!
```ts
set empId(id: number) {
	this.#id = id
}
get empId(): number {
	return this.#id
}

john.empId = 100
```

### Interfaces
with an interface, you can make your own datatype (user classes for return types tho)
```ts
interface Address {
	street?: string  //optional property
	city: string
	state: string
	zip: string
}

class Employee {
	name: string
	address: Address

	constructor(name: string, address: Address){
	this.name = name
	this.address = address
	}
}

let john = Employee("John", {
	street: "Example St.",
	city: "Denver",
	state: "IL",
	zip: "12345"
})
```

interfaces can of course also define function signatures:
```ts
export interface Login {
	login(): User
}
```
^export as you go
use with:
```ts
import {Login} from './interface'

class Manager implements Login {
	login() : User {
		//actual function
	}
}
```

batch import: 
```ts
import * as UserLogin from './interface'

class Manager implements UserLogin.Login
```


### Object and Array destructuring
```ts
let user : User = {name: "John", age: 18}
user.name
user.age
// can be written as:
let {name : userName, age} : User = {name: "John", age: 18}
userName  // you can use different names here
age

let [user1, user2, ...restUsers] : User[] = [
{name: "John"},
{name: "Alice"},
{name: "Bob"}
] 
```

