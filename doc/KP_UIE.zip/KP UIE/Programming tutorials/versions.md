angular 12.2.18  (npm install -g @angular/cli@12.2.18)
node 14.17.5  (https://nodejs.org/en/blog/release/v14.17.5)
npm 6.14.14