https://www.youtube.com/watch?v=2Ji-clqUYnA
(mainly the basics though, not terribly many projects)

## Keybinds and useful things
to quickly generate an index.html: Shift + !, it will then show the Emmet abbreviation

Ctrl+Shift+V to preview page on side panel (or choose from right mouse menu)
- refreshes on save, very nice

Ctrl+P for command prompt thingy
then ">Open User settings (JSON)"

cool Emmet thing:
`.special#first` generates `<div class="special" id="first"></div>`

Ctrl+Space for the lil suggestions popup


## Fundamentals
- let for variables (var is function scope, not block scope)
- const for constants
- variable names in camelCase
- backticks are useful for template strings
- javascript is loosely typed, so types don't need to be declared
- += and ++ are a thing, yay
- == checks for value equality
- === checks for value *and type* equality
- !== only negates the value, not the type equality
- || and &&
- negative indices are supported

- stuff like "10" is implicitly converted when you try and do math conversions on it (like in python, blessing and curse ^^")
	- you gotta be really careful with + there
- `document.getElementById('...').value` gives back a string, so you gotta do a 
  `value = parseInt(value` on it

### Types
- typeof operator, very useful (typeof variable)
- there is a difference between null and undefined
- arrays, functions and objects are all Object
- no int or float, just number
- typeof null is Object, even though it should be null
- undefined is the standard value for variables

### Objects
- `const array = [1, 2, 3, "text", null]` -> can be multiple types per array
- `function` keyword for functions, i keep forgetting that
- semantic difference between parameters (in the signature) and arguments (in the call)

Function expressions
```js
const add = function addValues(num1, num2) {
	return num1 + num2
}
const value = add(5, 6)
```
- you can omit the name to make an anonymous function
- just a different way of defining a function

or an arrow function:
```js
const multiply = (num1, num2) => num1 * num2
```

objects can store functions too 
```js
const person = {
	name: "John",
	age: 40,
	education: true,
	siblings: ["Anna", "Peter"],
	greeting: function () {
		console.log("Hello, my name is John")
	} 
}
console.log(person.name)

//shorthand since ES6
const person = {
	greeting() {
		console.log("Hello, my name is John")
	}
}
```


### Switch statement
```js
switch (dice) {
	case 1:
		//do something
		break
	case 2:
		//do something
		break
	default:
		//do something
}
```


## Connecting the dots
### Template Literals
```js
const name = "John"
const value = `Hey it's ${name}`
```

nice little shortcut for console.log on multiple things:
```js
console.log({
	gas: gasTotal,
	food: foodTotal,
	random: randomTotal
})
```


### Reference vs Value
- primitive data types are stored directly in the variable
- for objects, the variable only stores a reference
```js
let number = 1
let number2 = number
number2 = 7
//number = 1, number2 = 7

let person = {name:"bob"}
let person2 = person
person2.name = "susy"
// both are now named susy

//to "deepcopy" person, we'd do something like (ES6+)
person2 = {...person}
```

### null vs undefined
undefined = javascript can't find a value
- variable without value
- missing function arguments
- missing object properties
null = developer set this value (and can be used in math like 0)

### ternary operator
```js
//shorthand for if then else
value ? console.log("true") : console.log("false")
```


### global vs local scope
- any variable outside {} is said to be global scope
- can be accessed anywhere in the program
- look out for name collisions and accidentally changing values

- you can have functions inside of functions, making this really fun

making a global variable inside a function:
```js
function foo() {
	let localVariable = 1
	globalVariable = 2
}
```
by not using a keyword the variable gets created as a global variable
-> only accessible after the first time calling foo()!


### Callback functions and Higher order functions
higher order function = function that takes a function as an argument or returns another function as a result
callback function = passed to another function as an argument and executed in that function

```js
function bar() { //callback function
	//does something
}
function foo(func) { //higher order function
	func()
	// do something else
}

foo(bar)
```


### powerful array methods
#### forEach
modifies the array, no new one
```js
numbers = [1, 2, 3, 4]

//option 1: set up callback function
function callbackFunction(){
	//do something
}
numbers.forEach(callbackFunction)

//option 2: anonymous function
numbers.forEach(function(n){
	//do something with n
})

//option 2b: arrow function 
```
#### map
returns a new array of same size
```js
numbers.map(callbackFunction)
```

useful example: extract list of ages from a data set
```js
const people = [
	{name: "peter", age: 20},
	{name: "bob", age: 25},
	{name: "susy", age: 30}
]
const ages = people.map(function (person) {
	return person.age
})
console.log(ages)  //gives back [20, 25, 30]
```
#### filter
returns a new array, size may vary
```js
const youngPeople = people.filter(function (person) {
	return person.age <= 25
})
```
#### find
- only returns a single instance (first match)
- undefined if nothing found
#### reduce
- iterates over an array and collapses all elements into one number/array/object/...
- callback function has 2 parameters: acc (total) and curr (current iteration/value)
- in the callback function, you always always always return the acc first! then write your logic
- you can also define initial value, which also defines which data type we get back
```js
const people = [
	{name: "peter", age: 20, salary: 200},
	{name: "bob", age: 25, salary: 200},
	{name: "susy", age: 30, salary: 300}
]

const total = people.reduce(function(acc, curr){
	acc += curr.salary
	return acc //!!!!!!
}, 0)
```


### Math module
- Math.min, max, floor, ceil, sqrt, ...
- Math.PI
- Math.random() by default gives back value from 0 to <1


### Date
```js
const months = ["January", ...]
const days = ["Monday", ...]

const date = new Date()  //gives you the current date
const month = months[date.getMonth()]  //since getMonth and stuff gives you an index
```



## DOM (Document Object Model)
### Select Elements
many ways to select things in DOM:
```js
document.body.style.color = "yellow"  //seems to only work for the body?
document.getElementById("btn").style.color
document.querySelector("element")

const element = document.getElementById("element") //element is now a node object
const name = element.nodeName
const css = element.style
//there are also node lists, which are arraylike objects
```
- document is a property of the window object
- alert() = window.alert()
- and so on
- also window applies to the tab, not the window in a Windows sense

console.dir(document) gives us all nodes and methods on document

getElementsByTagName() gives us a node list
- node list has length and indices, but no array methods
  ES6 solution:
```js
const items = document.getElementsByTagName("li")
const betterItems = [...items]
```
now we have a proper array and can use array methods

### QuerySelector and QuerySelectorAll
- with querySelectorAll, we can use array methods (yay)
- `#id`
- `.class`
- `li:last-child` last entry of a list

### Traversing the DOM tree
```html
<ul id="result">
	<li>apple</li>
	<li>orange</li>
	<li>banana</li>
	<li>pear</li>
	<li>tomato</li>
</ul>
<h2 id="special">this is special content</h2>
```
```js
const result = document.querySelector("#result")
const allChildren = result.childNodes  //includes whitespace elements, which are treated like text nodes
const children = result.children  //much nicer
const lastChild = result.lastChild  //can be whitespace too so beware!

const parent = result.parentElement  //can be stacked, up until html

const first = document.querySelector(".first")
const second = first.nextSibling.nextSibling  //skipping the whitespace element
//or skip the hassle:
const second = first.nextElementSibling
```

nodeValue and textContent:
- to change the text inside our h2, we can modify the nodeValue
- it can't be accessed directly from item though, the text is stored inside a child text node
```js
const item = document.getElementById("special")
const text = item.firstChild.nodeValue
```
easier way: textContent
```js
const text = item.textContent
```
or: innerText
```js
item.innerText = "foo"
```
or: innerHTML

### getAttribute and setAttribute, more on classes
```js
const classValue = item.getAttribute("class")
item.setAttribute("class", "foo")

const name = item.className

item.className = "foo bar"
//or
item.classList.add("foo", "bar")

item.classList.remove("bar")

result = item.classList.contains("bob")
if(result){
	//do something
}
```


### Creating elements
```html
<div id="result">
	<h2>heading</h2>
</div>
```
```js
const result = document.querySelector("#result")

//create empty element
const addedDiv = document.createElement("div")
//create text node
const text = document.createTextNode("a simple test div")
addedDiv.appendChild(text)

document.body.appendChild(addedDiv) //adds it as last element in body
result.appendChild(addedDiv)  //or this
document.body.insertBefore(addedDiv, result)  //or this
document.body.replaceChild(addedDiv, result)  //or this
```

removing with remove() or removeChild()


## Events
event object can give us some useful info
- event.currentTarget: element that the eventListener is tied to
- beware: event.target is the element that triggered the event, this distinction is relevant for nested elements
- event.type: click, keydown, ...

### Bubbling and Capturing
event bubbling (default): an event triggered by a (deeply) nested element travels all the way up the DOM and activates the eventListeners of higher elements as well
- for example, clicking a nested Element activates the "click" event for all elements above it (like divs, body, window)

this behavior can be stopped by adding event.stopPropagation() to an eventListener

you can instead use capturing by passing {capture: true} when adding an eventListener
- then the event goes from the root to the individual elements of the DOM tree


## Local storage and session storage
- privided by browser API
- essentially a table of key-value pairs (stored as strings!)
```js
localStorage.setItem("name", "John")
sessionStorage.setItem("name", "John")

const name = localStorage.getItem("name")

localStorage.removeItem("name")
localStorage.clear()

//check if in storage
if(localStorage.getItem("fruits")){
	//...
}
```

to store arrays and objects, you can use JSON.stringify() (and JSON.parse() to decode again)