https://www.youtube.com/watch?v=AAu8bjj6-UI
https://www.youtube.com/watch?v=3qBXWUpoPHo

### What is Angular?
- UI framework built by Google
- component-based framework for building apps
- typescript rewrite of AngularJS


### Architecture
1. at least one module (app module) (has a module decorator)
2. template (html)
3. metadata for the templates
4. services (usually a class for a single purpose)
5. components
   - building blocks of the application
   - comprised of
	   - a HTML template
	   - a typescript class that defines the behavior
	   - a css selector
	   - css styles (optional)


### Installation
- install node, which comes with npm
- navigate to your project folder
- npm init to create a package.json file
- npm i typescript
- tsc --init to initialize typescript

- tsc = typescript compiler
  running that in the terminal compiles all ts files into js files

- npm i @angular/cli -g
- ng version to check if the install was correct
- ng new appnamegoeshere to create a folder with a template project

### Single Page Applications
- does not make a server request for every URL request
- all the resources needed for rendering are sent to the client machine
- Angular has Routing functionality to create a SPA
- it also offers SSR (server side rendering) which supports SPA


[[Typescript Basics]]

### The workspace
tsconfig.json
- config file for stuff like strict mode and target
- also Angular-related flags

README.md
- a readme
- has some commangs in it

package.json
- all dependencies go here
- defines different commands like ng serve and ng test
- does it go into the production code? -> dependencies
- just for development purposes (like testing stuff)? -> devDependencies

package-lock.json
- like the poetry.lock, but since we're only two people we probably won't need it

angular.json
- workspace information about all the projects (so only 1 for us)
- prefix is interesting, it ties into the selector properties
- if you include multiple css files (like for bootstrap), register them under options -> styles
- js files go under options -> scripts

/src
- that's where the fun happens

main.ts
- execution starts here

/assets
- like the static folder

/app
- our code goes here

### Useful commands
ng serve -o  run application locally


### AppModule
```ts
bootstrapModule(AppModule)
```
- upon starting, it bootstraps AppModule
- AppModule is a cclass in app.module.ts
- it has the @NgModule decorator
- each app has at least one module, the root module (AppModule)
- AppModule has information about all the app's components
- also has information about all Angular-specific libraries the app uses


### Components
Components are your views.
- app.component.ts is the root component
- the root component gets loaded onto index.html

properties in @Component:
- selector: html tag to load the component into (these are reusable) (libraries and frameworks may give you custom html tags)
- templateUrl: template file (duh)
- alternatively, you can use template property for inline html (backticks for multiline)
- styleUrls: css file(s)
- alternatively styles for inline css


### How to make a new component
ng generate component componentNameHere
or: ng g c for short
example: ng g c rooms

to render the new rooms component, we have to include its html tag (app-rooms) in app.component.html
- this tag is our entry component

### Template Syntax
How to bind backend information to the frontend?
#### Interpolation
- can be used with any basic data type
- in html: {{ variableNameGoesHere }} (like Jinja2)
#### Property Binding
```html
<div [innerText]="numberOfRooms"></div
```
```ts
numberOfRooms = 10
```
- like a shortcut to normal js code
- the box around innerText is important (box syntax)
- you can do this with any valid html property
#### Event Binding
```html
<button (click)="toggle()">Click Me</button>
```
```ts
toggle(){
    this.hideRooms = !this.hideRooms
  }
```
- good for collecting information
- banana syntax

### Directives
- can change the behavior or appearance of your DOM
- can implement all lifecycle hooks
- can't have templates, just logic

#### Types of directives
Structural directives
- always costlier, since they change the behavior of the DOM (big performance hit)

Attribute directives

#### Built-in Directives
`*ngIf`
idea: if availableRooms is >0, we want to display a section with the available rooms
- why not just use hidden? then the elements are still in the DOM, means it gets very full very quickly
```html
<div *ngIf="rooms.availableRooms > 0">Rooms List</div> <!-- like {% if ... %} -->
{{ rooms ?? "No rooms" }} <!-- if rooms not available, display "No rooms"-->
{{ rooms?.availableRooms ?? "No rooms"}} <!-- this is called optional chaining -->

<table>
  <tr>
	<th>Room Number</th>
	<th>Room Type</th>
	<th>Room Price</th>
	<th>Room Amenities</th>
	<th>Check-In Time</th>
  </tr>
  <tr *ngFor="let room of roomList">
	<td>{{ room.number }}</td>
	<td>{{ room.type }}</td>
	<td>{{ room.price }}</td>
	<td>{{ room.amenities }}</td>
	<td>{{ room.checkinTime }}</td>
  </tr>
<!-- for even and odd values: -->
<tr *ngFor="let room of roomList; let e=even; let o=odd">
  <td>{{ e ? "Even" : "Odd" }}
<!-- running number (starts with 0!) -->
<tr *ngFor="let room of roomList; let i=index">
  <td>{{ i }}
```
- if one of the entries changes, all entries get re-rendered
- the star means it's a structural directive (they can modify the DOM)

```html
<div [ngSwitch]="role">
	<div *ngSwitchCase="'User'">Welcome User!</div>
	<div *ngSwitchCase="'Admin'">Welcome Admin!</div>
	<div *ngSwitchDefault>You are not authorized to view this page!</div>
</div>
```

```html
<tr *ngFor="let room of roomList; let e=even; let o=odd"
	[ngClass]="e ? 'even' : 'odd'"> <!-- and make even and odd css classes-->
  <td>{{ e ? "Even" : "Odd" }}

<div [ngStyle]="{'color': rooms?.availableRooms > 0 ? 'green' : 'tomato'}"
```


### Pipes
- used for data transformation
- don't change the actual object

Built-in pipes: DatePipe, Upper- and LowerCasePipe, CurrencyPipe, DecimalPipe, JsonPipe ...
Like in Jinja2, just look into the docs


### Adding Bootstrap
- ng add ngx-bootstrap 

### Lifecycle Hooks
- like a series of events that a component (instance) has to go through
- lifecycle ends when the component is destroyed
- each lifecycle hook has an interface

lifecycle hooks (in order):
- ngOnChange
- ngOnInit
- ngDoCheck
- ngAfterContentInit
- ngAfterContentChecked
- ngAfterViewInit
- ngAfterViewChecked
- ngOnDestroy

object is supposed to be rendered on the page -> the constructor is called -> constructor finishes -> ngOnInit
- use constructor for assigning variables and injecting services
- constructors should not have any blocking code
- use ngOnInit for any logic things

- onOnChange can be used for component communication

#### Component Communication
= when two or more components need to interact
-> multiple ways to achieve this

@Input and @Output
- Input decorator on property of the subcomponent

```ts
//Child component
  @Input() rooms: RoomList[] = []  
  @Output() selectedRoom = new EventEmitter<RoomList>()

  selectRoom(room: RoomList){
    this.selectedRoom.emit(room)
  }
```
