https://www.youtube.com/watch?v=Oe421EPjeBE

- Node.js is an environment to run Javascript outside of a browser
- can do frontend and backend

Differences to "normal" browser javascript
- no DOM
- no window object
- server side apps, as opposed to interactive apps
- Filesystem access


### Installing
- download from nodejs.org
- use installation wizard
- check with node --version 


### Creating a project
- make new folder and drag it into vs code
- app.js file
- make a terminal, node app.js runs the program

### Global variables in node
just some of the most useful ones:
- __ dirname - path to current directory
- __ filename - file name
- require - function ot use modules (CommonJS)
- module - info about the current module (file)
- process - info about environment where the program is being executed

```js
setInterval(() => {
	console.log("hi")
}, 1000)
```


### Modules
you'll execute one file, but the code is split up into multiple files - modules
- modules have an exports property, an object
- so if you wanna share variables or functions between modules, add them into the exports section:
```js
//names.js
module.exports = {john, peter}

//utils.js
module.exports = sayHi

//app.ja
const names = require('./names')
const sayHi = require('./5-utils')
sayHi(names.john)
sayHi(names.peter)

//alternatively: export as you go
module.exports.items = ["item1", "item2"]
module.exports.person = {name: "john"}

const data = require('/6-alternative-syntax')
```

remotely execute functions
```js
//7-mind-grenade.js
const num1 = 5
const num2 = 10

function addValues(){
	console.log(`The sum is ${num1 + num2}`)
}

addValues()

//app.js
require("./7-mind-grenade")
//and addValues gets executed, without us having to know it
```
-> when you import a module, you actually invoke it
