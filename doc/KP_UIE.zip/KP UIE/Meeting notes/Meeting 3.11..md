- Wie steht es mit den Beispieldaten?
	- mit Beispielaufgaben
- Feedback Pflichtenheft V1
	- weitere Fragen, Hinweise, was ist besonders wichtig?
	- das Dashboard hat ein Grid, aber wie soll ich das als Requirements aufschreiben? 
	  ->keine Ahnung, irgendwie halt v('-')v 
- Ablauf Montag (eingeplante Zeit scheint etwas kurz)
- Use case Analyse? oder nicht relevant?
	- Umfang use cases
- evtl. wegen Prüfung fragen (muss ich KP extra anmelden?)

### Pflichtenheft 
#### Dashboard
- Anforderungen neutral beschreiben
- gridstack und Alternativen aufführen
- Begründen, warum wir uns für gridstack entschieden haben

#### Use cases
- 4 use cases (so grob)
- für jede Visualisierung eine
- was will man darstellen, wie kommt man da hin?
-> Hauptziel des Nutzers, Erwartungshaltung
- weiß der Nutzer schon, was er will oder ist das explorieren?

#### Versionen
6.11. ist ever V1.5, nicht V2
V2 wird Bewertungsstandard


### Wizard
- Programm sagt: für diese Visualisierung kämen diese Attribute in Frage...
  -> visualisierungs-pipeline
- preview der daten in tabellarischen Form?
- hat der Nutzer schon eine Vision für das Diagramm?
- daher Reihenfolge, ob zuerst Visualisierungstyp oder Datensatz

- Ontologie gibt uns Schema-Informationen
  -> also zuerst in die Ontologie schauen ist eine Option

### MISC
Beispieldaten sind jetzt da

Visualisierung sollen Überblick über Daten geben

Excel-Visualisierungs-Editor mal anschauen

mehrere Starplots auf einmal generieren?

position und layout-information auch mit speichern

neben json auch localstorage oder eigene Datenbank denkbar



### Montag
- 15 min Präsentation
- an der Uni 
- 2-3 sparql-anfragen, die unsere Beispiele unterfüttern
- Ideen vorstellen, die umsetzbar wären
- paar Folien wären gut
- Beispiele durchziehen
- zeigen, was wir uns so gedacht haben, warum wir diese spezifischen Visualisierungen gewählt haben
- Schwerpunkt aber eher auf Tom-spezifischen Sachen
- konkrete Beispiele für Montag vorbereiten

Abschlusspräsentation 30.1.
davor nochmal Präsentation in der Firma

