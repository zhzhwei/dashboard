### startup with existing visualizations
- start app
- app looks for instance folder
- app looks for workspace.json in instance folder
- create layout based on workspace.json
	- config file names are linked in workspace.json (make sure to use safe names there)
	- load content based on config file
	- make sparql query to display tile? there's not a 1:1 relation to sparql query and visualization tho


presentation slides:
- 4 visualizations
- 2-3 sparql anfragen für unsere Beispiele
- konkrete Beispiele für unsere Visualisierungen