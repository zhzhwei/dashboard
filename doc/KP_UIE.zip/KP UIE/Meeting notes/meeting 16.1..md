Preview-Knopf:
automatischer Reload bei Checkbox onClick und input onFocusChange?
(input onChange ist exzessiv)


## Inventarsystem (größtenteils fertig)
- Kachel per Herz ins Inventar
- Kachel per Herz aus dem Inventar (sowohl Kachel selbst als auch "Original")
- wenn Kachel bearbeitet wird, ändert sich die Farbe auf schwarz
- alles ist skalierbar
- wenn man die Kachel nach unten zieht, wird es eine richtige Kachel (kommen zwar noch einige Fehler, aber naja)
- wenn man die linke Kachel löscht, bleibt die andere noch an ihrem Platz, das wollen wir noch ändern
- manchmal gibt es Kacheln mit einem schwarzen Herz, das ist ein Bug


Vorschau bei Skills gut
time irgendwas statt creationDate

barchart dropdowns gut

Ziel bis nächste Woche: Kachel fällt raus
2 Spalten?
links Daten, rechts Diagram
Endpräsentation: Ablauf Frontend und zugehöriges Backend in Relation setzen


line chart = zeitlicher Ablauf
-> leeres creationDate abfangen, Warnmeldung?

barchart höchstens Jahre?
So kategorien halt

averages, sums und so?

Anzahl der Skills denkbar

mehrere Jobnames wären cool, aber erstmal Kacheln generieren
statische Bilder sind bei der Demo auch möglich, so als sinnvolle Platzhalter
Pie chart und star plot ausgrauen?
eher Workflow zeigen

Knopfbeschriftungen klarer machen
nächste Woche laptop mitbringen
