### Organisatorisches
- Slack-Kanal beitreten
- dort können wir Fragen stellen
- dort schreiben "Projektbeschreibung liegt bereit", geht schneller als Email

- wir kriegen bald Zugang zu elevait GraphDB und Beispieldaten
- Benachrichtigung darüber über Slack

- V1 Projektbeschreibung/Pflichtenheft soll am 24.10. abgegeben werden

### Pflichtenheft
#### Allgemein
- Pflichtenheft wohnt mit im Repository
- 24.10. Abgabe V1
- dazu kriegen wir Feedback, dann Überarbeitung
- 6.11. Abgabe V2



#### Aufbau
- Unterteilung in Konzeptionellen Teil und Implementierungsteil
- mit Herausforderungen im konzeptionellen Teil
- Muss-Kriterien für Prototyp sind...

- aber auch explizit aufschreiben, was wir nicht umsetzen werden
- Fallback-Lösung/was muss auf jeden Fall gehen: Nutzer muss die query selbst zusammenbauen (config-Datei bearbeiten)

-> Minimumvarianten, stretch goals
aber im konzeptionellen Teil ruhig auch Idealzustand beschreiben

#### Ideen
- Screenshots von Spreadsheets/anderen Anwendungen, die uns inspiriert haben statt Skizzen
- die 4 geplanten Visualisierungen aufschreiben
	- deren Hauptanwendungen beschreiben
	- über Mehrwert für die Firma nachdenken 
- aber auch 1-2 Alternativen aufschreiben, falls was nicht klappt
- gutes nicht-funktionales Kriterium: Austauschbarkeit des Datensatzes


### Ideen für die Anwendung
#### Allgemein
- im Wesentlichen können da beliebige Datensätze visualisiert werden
  -> nicht zu sehr auf den Datensatz zuschneiden
- wir kriegen auch Schema-Informationen zu den Daten

- Wer benutzt die Anwendung später?
	- funktioniert für Leute ohne SPARQL-Kenntnisse (aber Visualization literacy, kann Diagramme lesen)
	- Konzept zielgruppenübergreifend, Implementierung schauen wir mal
- Auf welchen Geräten läuft das Programm? (small screen/big screen, mouse/touch)
	- wir können von PC mit großem Bildschirm ausgehen
	- Touchscreen kann Wunschkriterium sein, aber ist hier kein Muss
	- was müsste getan werden, damit es Touch unterstützt?
	- so ein typisches Stretch goal halt
	- aber hauptsächlich Desktop-Nutzung
#### Visualisierungen
- Scatterplot als Clustervisualisierung?
- verschiedene Facetten der Daten mit den Visualisierungen darstellen (also nicht 4 verschiedene Graphen)
- aber auch einfach umzusetzen aus praktischer Sicht

#### Aufbau der Anwendung
Gewünscht: Dashboard mit Kacheln
- Nutzer kann Kacheln rumschieben
- Größe verändern
- Fokus liegt aber auf der Visualisierung
-> Für so ein Kachelsystem gibt es sicher was Fertiges

Idee: Wizard/Visualisierungs-Editor
- Art der Visualisierung
- Welche Daten gemappt werden sollen (z.B. Verkaufszahlen über Zeit)
- (Zeitraum)
- daraus config-Datei generieren, speichern
- aus dieser config Datei dann die SPARQL-Query zusammenbauen
- und die Daten visualisieren

- Keine Interaktionen zwischen den Visualisierungen wie Brushing/Linking

- Fokus der Datenverarbeitung möglichst auf die SPARQL-Queries verlegen
	- Daten bereits gut darstellbar abfragen
	- nur wenig selbst rechnen
	- Funktionen wir Zählen und group-by und so bei SPARQL nutzen, sehr nützlich



Beispiel Stellenausschreibung
![[Pasted image 20231017142100.png]]
![[Pasted image 20231017142113.png]]

wie viele Fertigkeiten/Skills werden pro Stellenausschreibung gefragt?
wie viele Stellenbeschreibungen über die Zeit?
welche Berufe?








