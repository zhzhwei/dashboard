## Pflichtenheft V3
"Projektabschluss"
- was das Projekt erfüllt
- Entwicklerhandbuch (das in der Readme + Überblick Projektstruktur)
- TLA wäre super
- dependencies (Angular Version, klar, aber auch so gridstack)
- abschließende Screenshots, Frontend-Beschreibung (exemplarisch, verschiedene screenshots halt)
- bei Wizard Beschreibung zu den Schritten, kurz beschreiben was das macht
-> nach Funktionsblock oder Szenarien gegliedert
- lieber gut illustrieren als Romane schreiben 
- was geht nicht
- was ist noch offen (Mini-Ausblick?)
- semantische Unterscheidung Linechart und Barchart? (Line = zeitlich, bar = statistisches aggregieren zu semantischen Kategorien)
- die SPARQL-Abfragen, so die Folie ist gut


## Gitlab
Repo aufräumen, soll schon irgendwie fertig aussehen
Issues entweder schließen oder verbose aufschreiben, was so das Problem ist
Soll weiterführbar sein

Video kann auch unter doc

## Endpräsentation
Für Präsentation mal ein Beispiel runterschreiben
bei der Demo Leute abholen, quasi Geschichten erzählen
==kleinerer Datensatz, weniger komplex, aber einige kleine Gemeinheiten hat er==
Teil der Herausforderung war, dass wir mit einem kleinen Datensatz was allgemeines bauen sollen

vielleicht Titel/Jobname-Problem mit erwähnen, darum ja Vorschau und Binds

Sentiment: ja, wir wissen was wir hier tun
nur für die Implementierung hatten wir halt nicht genug Zeit

Zeit nächste Woche ist begrenzt, Prioritäten setzen

Bewertung: Präsentation, Abschlussdokument, Einschätzung durch Betreuer
Note wird in Komplexprüfung verrechnet 


## Plan
1. branches mergen (ist klar)
2. editor funktion
3. GUI hübscher machen
4. anderer diagramtyp

