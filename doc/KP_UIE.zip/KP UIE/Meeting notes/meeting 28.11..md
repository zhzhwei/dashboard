 Sarah als Vertretung für Tom

5.12. Abgabe Pflichtenheft V2
- Punkte präziser formulieren
- Unterscheidung optional/nicht-optional überdenken (Ziel für Umsetzung festlegen)
- Abschluss ist dann nur noch Bericht über Umsetzung/Ergebnis

Nutzen von Issues zum Abhaken (mit Zuweisung zu Bearbeiter)
- in Zukunft vor allem
- schon abgehakte nachzutragen wäre auch cool
- Issue board kann auch genutzt werden

höchstwahrscheinlich keine Vorstellung bei elevait vor Weihnachten
aber noch ein Treffen mit Annett vor Weihnachten

User guidance ist wichtig, also den Nutzer im Erstellen von Visualisierungen unterstützen
- dem Nutzer schon Anzahl von Werten mitliefern
- oder durch Schnelligkeit

keine Schatten in der UI 
Undo/redo? mal drüber nachdenken ob das geht
Herz für Favoriten ist misleading
oder vielleicht Favoriten-System zusammen mit dem Inventar?
bzw. statt Inventar
Menü mit Kacheln schiebt sich auf, also zwei Zustände des Knopfes?

im Tooltip kompletten Namen anzeigen
icons unten rechts, damit die nicht mit dem Titel überlappen?
oder innerer Rahmen für Diagramm und Titel
lange Titel abfangen


für tageweise Abfragen: alle unterschiedlichen Tage anfragen, reduziert die Anzahl an Abfragen