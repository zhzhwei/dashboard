- 30.1. Abschluss (spooky)
- Issues mit Punkten aus dem Pflichtenheft verlinken

job posting mit min 5 bewerbern
barchart: anzahl bewerber als y
mit einzelnen bars
bei x auswählen, ob das jobname oder bewerberzahl sein soll, ...
plus sortierung
plus farbe
vielleicht auch extra farbe für kategorie (wie fulltime job) (stretch goal)
kriterien ohne mehrwert ausschließen
config der Anzeige ist stretch goal
