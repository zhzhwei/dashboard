- Proportionen beschränken bei Kacheln? (aspect ratio)
- Mindestgrößen für Kacheln?
- Interaktion von Kacheln sehr interessant, Konzeptweise ins Pflichtenheft aufnehmen
- eine Kachel mit small multiples?
	- macht die Beziehung zwischen config-File und Kachel interessant
- Mittelwerte und Summen etc.
	- idee: default-grau ist Durchschnitt von allen Bewerbern
- gut an Kuchen und Star: sind quadratisch, funktioniert gut mit Kachel-System
- Donut chart: nicht mehr als ~4 Ringe, wird zu viel
- bei Daten filtern schauen, ob man eine neue Abfrage macht oder ob man Werte zwischenhält
- Fokus für mehrere star plots: Problem occlusion
- delete-Knopf auf Kachel oder in Editor

nächstes Treffen: 21.11. virtuell, 13:30 Uhr

**potenziell** Präsentation bei elevait am 5.12.
