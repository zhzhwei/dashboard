- Runterziehen der Kachel aus den Favoriten? Was genau macht das?
- Favoriten als Snapshot? wäre dann nicht bearbeitbar
- Entwicklerdoku -> cleane Prozessbeschreibung
- und Nutzerdokumentation
- entwickelt/getestet mit Version ...
- Dependency-Liste, keine 10 Installationsanleitungen
- andere Dokus verlinken wäre gut
- kann in die Readme

starplot vielleicht raus (Entscheidung vom 13.12.)
